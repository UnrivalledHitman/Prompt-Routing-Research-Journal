ESWA submission package -- The escalation tax
=============================================

Expert Systems with Applications reviews double-anonymised: reviewers never
see the authors. Only the title page and the cover letter name them; the
build refuses to package if a name, affiliation, e-mail or ORCID reaches the
manuscript, the supplementary material or the highlights.

Upload to Editorial Manager as follows.

  Cover_letter.pdf          Cover letter, from Suseta Datta. It states that
                            both authors have approved the manuscript; make
                            sure that is true before uploading.
  Title_page.docx           Title page (with author details): authors,
                            affiliation, the corresponding author's full
                            address and e-mail, acknowledgements, the
                            competing-interest declaration and the CRediT
                            statement. Title_page.pdf is the same, to check.
  manuscript.tex            Anonymised manuscript (LaTeX source), a single
                            file. Upload together with the four figures,
                            which it includes by file name.
  Figure_1.pdf ... _4.pdf   Figures, one file each, vector PDF with fonts
                            embedded.
  highlights.docx           Highlights (5 bullets, each <= 85 characters).
  Supplementary_material.pdf  Supplementary material (Tables S1-S8,
                            Figures S1-S6), anonymised, cited from the
                            manuscript.
  manuscript.pdf            For checking only: the PDF this source builds.
                            Editorial Manager builds its own from the .tex.

In the submission system, not as files:
  - authors in this order: Suseta Datta, then Indrajeet Mondal, who is the
    corresponding author; the order must match the title page;
  - the declarations tool (competing interests), which ESWA says "should
    always be completed", matching the declaration on the title page.
